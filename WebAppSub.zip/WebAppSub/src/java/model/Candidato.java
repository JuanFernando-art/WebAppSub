/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author juanf
 */
public class Candidato {
    //informacoes pessoais
    String nome;
    String email;
    String cpf;
    String nascimento;
    String telefone;
    String nacionalidade;
    String etnia;
    // ponto economico
    String renda_familiar;
    boolean insencao;
    String opcao_curso;
    // localizacao
    String cep;
    String logradouro;
    int numero;
    String bairro;
    String cidade;
    String estado;
    // getters e setters informações pessoais
    // nome
    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    // email
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    //cpf
    public String getCpf(){
        return cpf;
    }
    public void setCpf(String cpf){
        this.cpf = cpf;
    }
    // nascimento
    public String getNascimento(){
        return nascimento;
    }
    public void setNascimento(String nascimento){
        this.nascimento = nascimento;
    }
    // telefone
    public String getTelefone(){
        return telefone;
    }
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    // nacionalidade
    public String getNacionalidade(){
        return nacionalidade;
    }
    public void setNacionalidade(String nacionalidade){
        this.nacionalidade = nacionalidade;
    }
    // etnia
    public String getEtnia(){
        return etnia;
    }
    public void setEtnia(String etnia){
        this.etnia = etnia;
    }
    // getters e setters informações financeiras
    // renda familiar
    public String getRenda_familiar(){
        return renda_familiar;
    }
    public void setRenda_familiar(String renda_familiar){
        this.renda_familiar = renda_familiar;
    }
    // insencao
    public boolean getInsencao(){
        return insencao;
    }
    public void setInsencao(boolean insencao){
        this.insencao = insencao;
    }
    // opcao_curso
    public String getOpcao_curso(){
        return opcao_curso;
    }
    public void setOpcao_curso(String opcao_curso){
        this.opcao_curso = opcao_curso;
    }
    // getters e setters localização 
    //cep
    public String getCep(){
        return cep;
    }
    public void setCep(String cep){
        this.cep = cep;
    }
    //logradouro
    public String getLogradouro(){
        return logradouro;
    }
    public void setLogradouro(String logradouro){
        this.logradouro = logradouro;
    }
    //numero
    public int getNumero(){
        return numero;
    }
    public void setNumero(int numero){
        this.numero = numero;
    }
    //bairro
    public String getBairro(){
        return bairro;
    }
    public void setBairro(String bairro){
        this.bairro = bairro;
    }
    //cidade
    public String getCidade(){
        return cidade;
    }
    public void setCidade(String cidade){
        this.cidade = cidade;
    }
    //estado
    public String getEstado(){
        return estado;
    }
    public void setEstado(String estado){
        this.estado = estado;
    }
}
