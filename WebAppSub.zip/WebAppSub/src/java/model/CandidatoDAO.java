/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author juanf
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class CandidatoDAO {

    public boolean Cadastrar(Candidato c){

    String sql = "INSERT into candidato( nome, email, cpf, nascimento, telefone, nacionalidade, etnia, renda_familiar, insencao, opcao_curso, cep, logradouro, numero, bairro, cidade, estado) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    try(Connection conectar = ConectaBanco.conectar();
        PreparedStatement pstmt = conectar.prepareStatement(sql)){

        pstmt.setString(1, c.getNome());
        pstmt.setString(2, c.getEmail());
        pstmt.setString(3, c.getCpf()); 
        pstmt.setString(4, c.getNascimento());
        pstmt.setString(5, c.getTelefone());
        pstmt.setString(6, c.getNacionalidade());
        pstmt.setString(7, c.getEtnia());
        pstmt.setString(8, c.getRenda_familiar());
        pstmt.setBoolean(9, c.getInsencao());
        pstmt.setString(10, c.getOpcao_curso());
        pstmt.setString(11, c.getCep());
        pstmt.setString(12, c.getLogradouro());
        pstmt.setInt(13, c.getNumero());
        pstmt.setString(14, c.getBairro());
        pstmt.setString(15, c.getCidade());
        pstmt.setString(16, c.getEstado());

        pstmt.executeUpdate();
        return true;
    }catch(SQLException | ClassNotFoundException e){
        System.out.println("Erro ao cadastrar candidato: " + e.getMessage());
        return false;
        }
    }
}

