/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author juanf
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConectaBanco {
    public static Connection conectar() throws ClassNotFoundException{
        Connection conexao = null;
        try {
            // Registra o Driver do MySQL e faz a conexão com o banco 'inscricao'
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Lembre de ajustar a senha caso o seu MySQL local tenha alguma senha configurada
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/inscricao","root","Game@9847");
            
        } catch (SQLException ex) {
            System.out.println("Erro ao conectar com o banco de dados: " + ex.getMessage());
        }
        return conexao;
    }
}
